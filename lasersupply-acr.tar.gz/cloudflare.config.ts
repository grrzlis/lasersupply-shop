import { bindings, defineConfig, defineWorker } from "cf/config";

export default defineConfig({
  accountId: "8e5ade2175f6ddeecf5b634d25145a38",
  worker: defineWorker({
    name: "lasersupply-shop",
    entrypoint: "vinext/server/fetch-handler",
    compatibilityDate: "2026-10-11",
    compatibilityFlags: ["nodejs_compat"],
    assets: { notFoundHandling: "none", runWorkerFirst: ["/_vinext/static-cache/*"] },
    env: {
      ASSETS: bindings.assets(),
      DB: bindings.d1({ id: "a2612c2d-4892-4cef-9107-e353dfbaec12", name: "lasersupply-db" }),
      NEXT_PUBLIC_STORE_NAME: bindings.text("LaserSupply.org"),
      NEXT_PUBLIC_STORE_TAGLINE: bindings.text("The European Hub for Laser Maker Blanks & Materials"),
      NEXT_PUBLIC_SUPPORT_EMAIL: bindings.text("info@lasersupply.org"),
      ADMIN_NOTIFICATION_EMAIL: bindings.text("akdarbas@gmail.com"),
      ALIEXPRESS_APP_KEY: bindings.text("552890"),
      ALIEXPRESS_APP_SECRET: bindings.text("sGSfN94PE0gxWX1XfHuIzsbg0rqmW1Yt"),
      ALIEXPRESS_ACCESS_TOKEN: bindings.text("50000700320cBHtYbrSjsgJFsyNyCabm14765485xhmUgwwD9dhRCK01Gj7vRNzFPOM3"),
      ALIEXPRESS_REFRESH_TOKEN: bindings.text("50001700620rpPvJesEnBNXsuc97IvFo14b01583tewTjbjBS5rT2ColxkPFbKV1TNYv"),
      BREVO_NEWSLETTER_LIST_ID: bindings.text("7"),
      ADMIN_PASSWORD: bindings.text("LaserMaker#2026"),
    },
  }),
});
