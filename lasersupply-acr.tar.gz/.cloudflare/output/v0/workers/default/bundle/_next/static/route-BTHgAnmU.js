import{n as e}from"./server-CeUkwBo-.js";import{getDb as t}from"./db-CuOJJNmn.js";async function n(e){let t=new TextEncoder().encode(`salt_ls_${e}`),n=await crypto.subtle.digest(`SHA-256`,t);return Array.from(new Uint8Array(n)).slice(0,8).map(e=>e.toString(16).padStart(2,`0`)).join(``)}async function r(r){try{let{sessionId:i,path:a,referrer:o,device:s,cartCount:c}=await r.json()||{};if(!i)return e.json({ok:!1},{status:400});let l=r.headers,u=l.get(`cf-ipcountry`)||l.get(`x-vercel-ip-country`)||`EU`,d=l.get(`cf-ipcity`)||``,f=l.get(`cf-connecting-ip`)||l.get(`x-forwarded-for`)||`127.0.0.1`,p=l.get(`user-agent`)||``,m=s||`desktop`;s||/mobile|android|iphone|ipad|phone/i.test(p)&&(m=`mobile`);let h=await n(f),g=Date.now(),_=await t();if(_&&(await _.prepare(`
        INSERT INTO visitor_sessions (
          id, ip_hash, country, city, current_path, referrer, device, cart_count, last_active_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (id) DO UPDATE SET
          current_path = EXCLUDED.current_path,
          cart_count = EXCLUDED.cart_count,
          last_active_at = EXCLUDED.last_active_at
      `).bind(i,h,u,d,a||`/`,(o||``).slice(0,200),m,Number(c||0),g,g).run(),Math.random()<.05)){let e=g-2592e6;await _.prepare(`DELETE FROM visitor_sessions WHERE last_active_at < ?`).bind(e).run()}return e.json({ok:!0})}catch(t){let n=t instanceof Error?t.message:`Error`;return console.error(`Ping tracking error:`,n),e.json({ok:!1,error:n},{status:200})}}export{r as POST};