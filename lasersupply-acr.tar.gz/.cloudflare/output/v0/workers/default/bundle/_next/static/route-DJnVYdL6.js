import{n as e}from"./i18n-DbQkMrsk.js";import{n as t}from"./server-CeUkwBo-.js";import{t as n}from"./products-BjRsGARR.js";function r(e){switch(e){case`cat_wood`:return`Arts & Entertainment > Hobbies & Creative Arts > Crafts & Hobbies > Woodworking`;case`cat_metal`:return`Arts & Entertainment > Hobbies & Creative Arts > Crafts & Hobbies > Jewelry Making & Beading`;case`cat_optics_safety`:return`Business & Industrial > Work Safety Protective Gear > Safety Glasses & Goggles`;case`cat_hardware`:return`Hardware > Hardware Accessories > Tool Parts & Accessories`;case`cat_filament`:return`Arts & Entertainment > Hobbies & Creative Arts > Crafts & Hobbies`;default:return`Arts & Entertainment > Hobbies & Creative Arts > Crafts & Hobbies`}}function i(e){return e?e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&apos;`):``}var a=new Set([`prod_sculpfun_72`,`prod_sculpfun_69`,`prod_sculpfun_82`,`prod_sculpfun_78`,`prod_sculpfun_89`,`prod_sculpfun_90`,`prod_sculpfun_91`,`prod_sculpfun_86`,`prod_sculpfun_92`,`prod_sculpfun_93`,`prod_sculpfun_67`,`prod_sculpfun_68`,`prod_sculpfun_79`,`prod_sculpfun_80`,`prod_cloudray_16`,`prod_cloudray_29`,`prod_cloudray_31`,`prod_cloudray_37`,`prod_cloudray_38`,`prod_ortur_100`,`prod_ortur_99`,`prod_ortur_98`,`prod_ortur_97`,`prod_ortur_95`]);async function o(o){try{let s=new URL(o.url).searchParams.get(`locale`)||`en`,c=e.includes(s)?s:`en`,l=`https://lasersupply.org`,u=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
  <channel>
    <title>LaserSupply.org Google Shopping Product Feed</title>
    <link>${l}</link>
    <description>Europe&apos;s leading supplier of laser engraving blanks, materials, and maker accessories.</description>
${n.filter(e=>!a.has(e.id)).map(e=>{let t=e.name_i18n?.[c]||e.name,n=e.description_i18n?.[c]||e.description,a=`${l}/${c}#${e.id}`,o=e.images?.[0]||`https://lasersupply.org/icon-512.png`,s=(e.images||[]).slice(1,5),u=r(e.category_id),d=e.specs?.Brand||``;d||=e.name.includes(`Cloudray`)||e.badge?.includes(`Cloudray`)?`Cloudray`:e.name.includes(`Sculpfun`)||e.badge?.includes(`Sculpfun`)?`Sculpfun`:e.name.includes(`Ortur`)||e.badge?.includes(`Ortur`)?`Ortur`:e.name.includes(`Elegoo`)||e.badge?.includes(`Elegoo`)?`Elegoo`:e.name.includes(`Polymaker`)||e.badge?.includes(`Polymaker`)?`Polymaker`:`LaserSupply`;let f=e.supplier_sku||e.cj_pid||e.id,p=`${Number(e.price).toFixed(2)} EUR`,m=s.map(e=>`      <g:additional_image_link>${i(e)}</g:additional_image_link>`).join(`
`);return`    <item>
      <g:id>${i(e.id)}</g:id>
      <g:title>${i(t)}</g:title>
      <g:description>${i(n)}</g:description>
      <g:link>${i(a)}</g:link>
      <g:image_link>${i(o)}</g:image_link>
${m?m+`
`:``}      <g:condition>new</g:condition>
      <g:availability>in_stock</g:availability>
      <g:price>${p}</g:price>
      <g:brand>${i(d)}</g:brand>
      <g:google_product_category>${i(u)}</g:google_product_category>
      <g:mpn>${i(f)}</g:mpn>
      <g:identifier_exists>yes</g:identifier_exists>
      <g:shipping>
        <g:country>LT</g:country>
        <g:service>Tracked Express</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>LV</g:country>
        <g:service>Tracked Express</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>EE</g:country>
        <g:service>Tracked Express</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>DE</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>FR</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>DK</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>PL</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>ES</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>IT</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>NL</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>BE</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>AT</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>SE</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>FI</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>IE</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>SK</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>CZ</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>PT</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>HU</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>RO</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>BG</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>SI</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>HR</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>GR</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>LU</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>CY</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>MT</g:country>
        <g:service>EU Tracked Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>NO</g:country>
        <g:service>Tracked International Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>CH</g:country>
        <g:service>Tracked International Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
      <g:shipping>
        <g:country>GB</g:country>
        <g:service>Tracked International Courier</g:service>
        <g:price>0.00 EUR</g:price>
      </g:shipping>
    </item>`}).join(`
`)}
  </channel>
</rss>`;return new t(u,{status:200,headers:{"Content-Type":`application/xml; charset=utf-8`,"Cache-Control":`public, max-age=3600, s-maxage=14400`}})}catch(e){let n=e instanceof Error?e.message:`Feed generation error`;return t.json({error:n},{status:500})}}export{o as GET};