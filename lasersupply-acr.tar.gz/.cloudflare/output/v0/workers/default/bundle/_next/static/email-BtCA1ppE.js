import{n as e,t}from"./runtime-env-B_GrCYyc.js";async function n(){return((await e()).BREVO_API_KEY||process.env.BREVO_API_KEY)?.trim()||void 0}async function r(){let n=(await e()).BREVO_NEWSLETTER_LIST_ID||process.env.BREVO_NEWSLETTER_LIST_ID||t(`BREVO_NEWSLETTER_LIST_ID`,`7`),r=Number(n);return Number.isFinite(r)&&r>0?r:7}async function i(e,t){let i=await n();if(!i)return console.warn(`⚠️ [BREVO] BREVO_API_KEY not configured. Skipping newsletter subscribe.`),{success:!1,reason:`missing_key`};let a=await r(),o=e.trim().toLowerCase();try{let e=await fetch(`https://api.brevo.com/v3/contacts`,{method:`POST`,headers:{"api-key":i,"Content-Type":`application/json`,Accept:`application/json`},body:JSON.stringify({email:o,updateEnabled:!0,listIds:[a],attributes:t?{LOCALE:t}:void 0})});if(e.ok||e.status===204)return{success:!0};let n=await e.text();return e.status===400&&/already|duplicate|exist/i.test(n)?{success:!0,already:!0}:(console.error(`❌ [BREVO] Newsletter subscribe failed:`,e.status,n),{success:!1,error:n})}catch(e){return console.error(`❌ [BREVO] Newsletter subscribe network error:`,e),{success:!1,error:e}}}async function a({to:e,subject:t,htmlContent:r}){let i=await n();if(!i)return console.warn(`⚠️ [BREVO] BREVO_API_KEY not configured. Skipping email send.`),{success:!1,reason:`missing_key`};try{let n=await fetch(`https://api.brevo.com/v3/smtp/email`,{method:`POST`,headers:{"api-key":i,"Content-Type":`application/json`,Accept:`application/json`},body:JSON.stringify({sender:{name:`LaserSupply.org`,email:`info@lasersupply.org`},to:e,subject:t,htmlContent:r})});if(!n.ok){let e=await n.text();return console.error(`❌ [BREVO] Email send failed:`,n.status,e),{success:!1,error:e}}let a=await n.json();return console.log(`✅ [BREVO] Email sent successfully:`,a),{success:!0,data:a}}catch(e){return console.error(`❌ [BREVO] Network or runtime error sending email:`,e),{success:!1,error:e}}}async function o({orderId:e,customerEmail:t,customerName:n,trackingNumber:r,carrierName:i=`AliExpress Standard Shipping`,trackingUrl:o=`https://t.17track.net/en#nums=${r}`}){let s=`🚚 Your Order #${e} Has Shipped! - LaserSupply.org`,c=`
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e5e7eb; border-radius: 8px;">
      <h2 style="color: #111827; margin-top: 0;">Great news! Your package is on its way.</h2>
      <p>Hi ${n||`Valued Customer`},</p>
      <p>Your order <strong>#${e}</strong> has been dispatched and is traveling to your delivery address.</p>
      
      <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin: 24px 0; border: 1px solid #e5e7eb;">
        <p style="margin: 0 0 10px 0; font-size: 14px;"><strong>Carrier:</strong> ${i}</p>
        <p style="margin: 0 0 16px 0; font-size: 14px;"><strong>Tracking Number:</strong> <code style="background: #e5e7eb; padding: 3px 6px; border-radius: 4px; font-weight: bold;">${r}</code></p>
        <div style="margin-top: 16px;">
          <a href="${o}" target="_blank" rel="noopener noreferrer" style="background-color: #f5cb5c; color: #1c1c1b; text-decoration: none; font-weight: bold; padding: 12px 20px; border-radius: 6px; display: inline-block;">
            Track Your Package &rarr;
          </a>
        </div>
      </div>

      <p style="color: #4b5563; font-size: 14px;">It can take up to 24–48 hours for tracking details to update with the courier.</p>
      <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;" />
      <p style="color: #9ca3af; font-size: 12px; margin: 0;">LaserSupply.org — European Laser Maker Blanks & Materials</p>
    </div>
  `;return a({to:[{email:t,name:n}],subject:s,htmlContent:c})}export{o as n,i as r,a as t};