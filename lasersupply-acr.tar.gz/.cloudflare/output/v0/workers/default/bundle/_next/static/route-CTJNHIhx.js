import{n as e}from"./i18n-DbQkMrsk.js";import{n as t}from"./server-CeUkwBo-.js";async function n(){let n=`https://lasersupply.org`,r=new Date().toISOString(),i=e.map(e=>`  <url>
    <loc>${n}/${e}</loc>
    <lastmod>${r}</lastmod>
    <changefreq>daily</changefreq>
    <priority>${e===`en`?`1.0`:`0.9`}</priority>
  </url>`);for(let e of[`/returns`,`/shipping`,`/privacy`])i.push(`  <url>
    <loc>${n}${e}</loc>
    <lastmod>${r}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>`);let a=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${i.join(`
`)}
</urlset>`;return new t(a,{status:200,headers:{"Content-Type":`application/xml; charset=utf-8`,"Cache-Control":`public, max-age=3600, s-maxage=14400`}})}export{n as GET};