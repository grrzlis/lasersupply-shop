import{n as e}from"./server-CeUkwBo-.js";async function t(){return new e(`User-agent: *
Allow: /
Disallow: /admin
Disallow: /api/

Sitemap: https://lasersupply.org/sitemap.xml
`,{status:200,headers:{"Content-Type":`text/plain; charset=utf-8`,"Cache-Control":`public, max-age=86400`}})}export{t as GET};