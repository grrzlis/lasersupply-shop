import{n as e}from"./server-CeUkwBo-.js";import{getDb as t}from"./db-CuOJJNmn.js";import{n,t as r}from"./email-BtCA1ppE.js";import{queryAliExpressOrderStatus as i}from"./aliexpress-client-GfXFv1-f.js";async function a(a){try{let o=new URL(a.url).searchParams.get(`key`),s=process.env.ADMIN_SYNC_SECRET||`lasersupply-sync-2026`;if(o&&o!==s)return e.json({ok:!1,error:`Unauthorized: Invalid sync key`},{status:401});let c=await t();if(!c)return e.json({ok:!1,error:`Database not available`},{status:500});let l=(await c.prepare(`
      SELECT id, customer_name, customer_email, supplier_order_id, fulfillment_status, tracking_number
      FROM orders
      WHERE payment_status = 'paid'
        AND (fulfillment_status IS NULL OR fulfillment_status NOT IN ('fulfilled', 'delivered', 'simulated_test'))
        AND supplier_order_id IS NOT NULL
      LIMIT 25
    `).all()).results||[],u=[];for(let e of l){let t=e.supplier_order_id;if(!t)continue;let a=await i(t);if(a.success&&a.isShipped){let i=a.trackingNumber||e.tracking_number||`IN-TRANSIT`,o=a.trackingUrl||`https://t.17track.net/en#nums=${i}`,s=a.logisticsServiceName||`AliExpress Standard Shipping`;await c.prepare(`
          UPDATE orders
          SET fulfillment_status = 'fulfilled',
              tracking_number = ?,
              tracking_url = ?
          WHERE id = ?
        `).bind(i,o,e.id).run(),e.customer_email&&await n({orderId:e.id,customerEmail:e.customer_email,customerName:e.customer_name||`Customer`,trackingNumber:i,carrierName:s,trackingUrl:o});let l=process.env.ADMIN_NOTIFICATION_EMAIL||`akdarbas@gmail.com`;await r({to:[{email:l,name:`LaserSupply Admin`}],subject:`🚚 Užsakymas #${e.id} išsiųstas AliExpress! (Sekimo Nr: ${i})`,htmlContent:`
            <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
              <h2>🚚 AliExpress išsiuntė užsakymą!</h2>
              <p>Parduotuvės užsakymas: <strong>#${e.id}</strong></p>
              <p>AliExpress užsakymo ID: <strong>${t}</strong></p>
              <p>Sekimo numeris: <strong>${i}</strong> (${s})</p>
              <p>Klientui (${e.customer_email}) automatiškai išsiųstas pranešimas su sekimo nuoroda.</p>
              <p><a href="${o}" target="_blank">Sekti siuntą &rarr;</a></p>
            </div>
          `}),u.push({orderId:e.id,status:`fulfilled`,trackingNumber:i,customerNotified:!!e.customer_email})}}return e.json({ok:!0,timestamp:new Date().toISOString(),checkedCount:l.length,updatedCount:u.length,updates:u})}catch(t){let n=t instanceof Error?t.message:`Error syncing fulfillment`;return e.json({ok:!1,error:n},{status:500})}}async function o(e){return a(e)}export{a as GET,o as POST};