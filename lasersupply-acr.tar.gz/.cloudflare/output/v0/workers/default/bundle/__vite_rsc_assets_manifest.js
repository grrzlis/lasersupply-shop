export default {
  "clientEntryUrl": "/_next/static/chunks/index-CdPAA7pd.js",
  "clientEntryDeps": {
    "js": [
      "/_next/static/chunks/index-CdPAA7pd.js",
      "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
      "/_next/static/chunks/framework-VZQ7zkYr.js",
      "/_next/static/chunks/vinext-BY7Y15_v.js"
    ],
    "css": []
  },
  "clientReferenceDeps": {
    "339f946bc456": {
      "js": [
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js"
      ],
      "css": []
    },
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "3b65333b902f": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/layout-segment-context-BIOfY5qI.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "c2747888630f": {
      "js": [
        "/_next/static/chunks/link-nXwQIjYA.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "89c3cac48cb5": {
      "js": [
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "927fe43b75aa": {
      "js": [
        "/_next/static/chunks/page-CiDKCntf.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/createLucideIcon-DhIKkMLA.js",
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/index-CdPAA7pd.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js"
      ],
      "css": []
    },
    "6c0a30b1853a": {
      "js": [
        "/_next/static/chunks/BackToTop-CSy4VIh3.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/createLucideIcon-DhIKkMLA.js",
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/index-CdPAA7pd.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js"
      ],
      "css": []
    },
    "0d9e8c532e42": {
      "js": [
        "/_next/static/chunks/CatalogWithSidebar-CIWMICsI.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/createLucideIcon-DhIKkMLA.js",
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/image-BQUkLzIx.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/translations-d5Rkhon8.js",
        "/_next/static/chunks/categories-Du434uMG.js",
        "/_next/static/chunks/cart-store-BBpaKjpl.js",
        "/_next/static/chunks/products-a2Gggeam.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "51a5641f99d4": {
      "js": [
        "/_next/static/chunks/CategoryShowcase-B4bRiEXk.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/categories-Du434uMG.js",
        "/_next/static/chunks/products-a2Gggeam.js",
        "/_next/static/chunks/index-CdPAA7pd.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js"
      ],
      "css": []
    },
    "a0439d8a2cb6": {
      "js": [
        "/_next/static/chunks/Navbar-BIAKsPHZ.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/link-nXwQIjYA.js",
        "/_next/static/chunks/createLucideIcon-DhIKkMLA.js",
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/translations-d5Rkhon8.js",
        "/_next/static/chunks/categories-Du434uMG.js",
        "/_next/static/chunks/cart-store-BBpaKjpl.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "c56a9d69e06e": {
      "js": [
        "/_next/static/chunks/SlideOverCart-BBf-v79n.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/createLucideIcon-DhIKkMLA.js",
        "/_next/static/chunks/Icon-B5aUKEzb.js",
        "/_next/static/chunks/image-BQUkLzIx.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/translations-d5Rkhon8.js",
        "/_next/static/chunks/cart-store-BBpaKjpl.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    },
    "d59756e22e6a": {
      "js": [
        "/_next/static/chunks/VisitorTracker-03TSIs1l.js",
        "/_next/static/chunks/rolldown-runtime-hePW80VL.js",
        "/_next/static/chunks/framework-VZQ7zkYr.js",
        "/_next/static/chunks/vinext-BY7Y15_v.js",
        "/_next/static/chunks/cart-store-BBpaKjpl.js",
        "/_next/static/chunks/index-CdPAA7pd.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "src/app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.NUAye324.css"
      ]
    }
  }
}